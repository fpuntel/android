/*
 * 						Universidade Federal de Santa Catarina - UFSC
 * 								   	Campus Ararangu�
 * 						LARM - Laborat�rio de  Automa��o e Rob�tica M�vel
 *								 		D�motica
 *
 * Este software est� licenciado sobre Licen�a Apache, Vers�o 2.0 (a "Licen�a")
 * Voc� n�o pode usar esse arquivo exceto em conformidade com a Licen�a.
 * Voc� pode obter uma c�pia da Licen�a em
 * http://www.apache.org/licenses/LICENSE-2.0
 * A menos que exigido por lei aplic�vel ou acordado por escrito de software,
 * Distribu�do sob a Licen�a � distribu�do "COMO EST�",
 * SEM GARANTIAS OU CONDI��ES DE QUALQUER TIPO, expressa ou impl�cita.
 * Consulte a Licen�a para a linguagem espec�fica que regula permiss�es e
 * Os limita��es sob a Licen�a.
 * Peda�os do c�digo baseado no c�digo do site: http://www.karelbruneel.com/blog/
 *  
 * C�digo com a iten��o de controlar os comodos de uma casa, tanto luz, como alarme e port�o
 * C�digo desenvolvido por Fernando Emilio Puntel (fernandopuntel@gmail.com);
 */

package bluetoothSteeringWheel.karelbruneel.com;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.os.Binder;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;

public class BluetoothSPPConnection {
    
    private BluetoothDevice mDevice;    
    private final BluetoothAdapter mAdapter;

    private ConnectThread mConnectThread;
    private ConnectedThread mConnectedThread;
    
    private ListenerDelegate mListener;


    public BluetoothSPPConnection(BluetoothSPPConnectionListener btListener) {	
        mAdapter = BluetoothAdapter.getDefaultAdapter();
        mListener = new ListenerDelegate(btListener, null);
    }

    
    public String getDeviceName() {
    	return mDevice.getName();
    }

    public synchronized void open(BluetoothDevice device) {

    	mDevice = device;

        mConnectThread = new ConnectThread(device);
        mConnectThread.start();
        
        mListener.onConnecting();
    }

    public synchronized void close() {

        if (mConnectThread != null) {
        	mConnectThread.cancel(); 
        	mConnectThread = null;
        }

        if (mConnectedThread != null) {
        	mConnectedThread.cancel(); 
        	mConnectedThread = null;
        }

    }

    public void write(byte[] out) {
    	if (mConnectedThread != null) {
    		mConnectedThread.write(out);
    	}
    }

    private class ConnectThread extends Thread {
        private final BluetoothSocket mmSocket;

        public ConnectThread(BluetoothDevice device) {
            // Utilize um objeto tempor�rio e depois o  mmSocket,
            // porque mmSocket � o final
            BluetoothSocket tmp = null;

            try {
                tmp = device.createRfcommSocketToServiceRecord(UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"));
            } catch (IOException e) { }
            mmSocket = tmp;
        }

        public void run() {
            mAdapter.cancelDiscovery();

            try {
                mmSocket.connect();
            } catch (IOException connectException) {
                try {
                	mListener.onConnectionFailed();
                    mmSocket.close();
                } catch (IOException closeException) { }
                return;
            }

            mConnectedThread = new ConnectedThread(mmSocket);
            mConnectedThread.start();
            
            mListener.onConnected();

      }

        //Se ter� que fechar a conex�o e fechar o Socket
        public void cancel() {
            try {
                mmSocket.close();
            } catch (IOException e) { }
        }
    }
    
    
    private class ConnectedThread extends Thread {
        private final BluetoothSocket mmSocket;
        private final InputStream mmInStream;
        private final OutputStream mmOutStream;

        public ConnectedThread(BluetoothSocket socket) {
            mmSocket = socket;
            InputStream tmpIn = null;
            OutputStream tmpOut = null;

            try {
                tmpIn = socket.getInputStream();
                tmpOut = socket.getOutputStream();
            } catch (IOException e) { }

            mmInStream = tmpIn;
            mmOutStream = tmpOut;
        }

        public void run() {
            byte[] buffer = new byte[1024];  //Mem�ria para fluxo
            int bytes; 
            while (true) {
                try {
                    // Leia a partir do InputStream
                    bytes = mmInStream.read(buffer);
                    mListener.bluetoothWrite(bytes,buffer);
                } catch (IOException e) {
                	mListener.onConnectionLost();
                    break;
                }
            }
        }

        /*
         * Essa � chamada de atividade pricnipal pois enviar� dados para
         * o dispositivo remoto
         */
        public void write(byte[] bytes) {
            try {
                mmOutStream.write(bytes);
            } catch (IOException e) { }
        }

        /*
         * Essa � chamada de atividade principal para desligar a liga��o
         */
        public void cancel() {
            try {
                mmSocket.close();
            } catch (IOException e) { }
        }
    }
    
    private class ListenerDelegate extends Binder {

        public static final int MESSAGE_CONNECTING = 1;
        public static final int MESSAGE_CONNECTED = 2;
        public static final int MESSAGE_CONNECTION_LOST = 3;
        public static final int MESSAGE_CONNECTION_FAILED = 4;
        public static final int MESSAGE_WRITE = 5;
        
        final BluetoothSPPConnectionListener mBluetoothSerialEventListener;
        private final Handler mHandler;

        ListenerDelegate(BluetoothSPPConnectionListener listener, Handler handler) {
        	mBluetoothSerialEventListener = listener;
            Looper looper = (handler != null) ? handler.getLooper() : Looper.getMainLooper();

            mHandler = new Handler(looper) {
                @Override
                public void handleMessage(Message msg) {
                    switch (msg.what) {
                    /*
                     * Verifica a conex�o e entra no case da conex�o
                     * Cada case mostra uma mensagem para o usuario
                     */
                    case MESSAGE_CONNECTING:
                    	mBluetoothSerialEventListener.onConnecting();
                        break;
                    case MESSAGE_CONNECTED:
                    	mBluetoothSerialEventListener.onConnected();
                        break;
                    case MESSAGE_CONNECTION_LOST:
                    	mBluetoothSerialEventListener.onConnectionLost();
                        break;
                    case MESSAGE_CONNECTION_FAILED:
                    	mBluetoothSerialEventListener.onConnectionFailed();
                        break;
                    case MESSAGE_WRITE:
                    	byte[] buffer = (byte[]) msg.obj;
                    	int bytes = msg.arg1;
                    	mBluetoothSerialEventListener.bluetoothWrite(bytes, buffer);
                        break;
                    }
                }
            };

        }

    	void bluetoothWrite(int bytes, byte[] buffer) {
    		mHandler.obtainMessage(MESSAGE_WRITE, bytes, -1, buffer).sendToTarget();
    	}
    	void onConnecting() {
    		mHandler.obtainMessage(MESSAGE_CONNECTING).sendToTarget();
    	}
    	void onConnected(){
    		mHandler.obtainMessage(MESSAGE_CONNECTED).sendToTarget();
    	}
    	void onConnectionFailed() {
    		mHandler.obtainMessage(MESSAGE_CONNECTION_FAILED).sendToTarget();
    	}
    	void onConnectionLost() {
    		mHandler.obtainMessage(MESSAGE_CONNECTION_LOST).sendToTarget();
    	}
        
    }

}
