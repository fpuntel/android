/*
 * 						Universidade Federal de Santa Catarina - UFSC
 * 								   	Campus Ararangu�
 * 						LARM - Laborat�rio de  Automa��o e Rob�tica M�vel
 *								 		D�motica
 *
 * Este software est� licenciado sobre Licen�a Apache, Vers�o 2.0 (a "Licen�a")
 * Voc� n�o pode usar esse arquivo exceto em conformidade com a Licen�a.
 * Voc� pode obter uma c�pia da Licen�a em
 * http://www.apache.org/licenses/LICENSE-2.0
 * A menos que exigido por lei aplic�vel ou acordado por escrito de software,
 * Distribu�do sob a Licen�a � distribu�do "COMO EST�",
 * SEM GARANTIAS OU CONDI��ES DE QUALQUER TIPO, expressa ou impl�cita.
 * Consulte a Licen�a para a linguagem espec�fica que regula permiss�es e
 * Os limita��es sob a Licen�a.
 * Peda�os do c�digo baseado no c�digo do site: http://www.karelbruneel.com/blog/
 *  
 * C�digo com a iten��o de controlar os comodos de uma casa, tanto luz, como alarme e port�o
 * C�digo desenvolvido por Fernando Emilio Puntel (fernandopuntel@gmail.com);
 */
package bluetoothSteeringWheel.karelbruneel.com;

import bluetoothSteeringWheel.karelbruneel.com.R;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.PowerManager;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class BluetoothSteeringWheel extends Activity implements SensorEventListener, BluetoothSPPConnectionListener {

	private static final int REQUEST_CONNECT_DEVICE = 1;
    private static final int REQUEST_ENABLE_BT = 2;
    	
	private SensorManager mSensorManager;
	private Sensor mAccelerometer;

	private BluetoothSPPConnection mBluetoothSPPConnection;
	private BluetoothAdapter mBluetoothAdapter = null;

	private PowerManager.WakeLock wl;
	
	private boolean connected=false;

	private float gravity[];
	private boolean drive=false;
	
	EditText edlog;
	//Menu Principal
	Button btSala;
	Button btCozinha;
	Button btQuarto;
	Button btGaragem;
	Button btBanheiro;
	Button btCasa;
	//SubMenus
	Button btVoltarMenu;
	Button btLuzCozinha;
	Button btLuzSala;
	Button btVentiladorSala;
	Button btLuzQuarto;
	Button btLuzBanheiro;
	Button btLuzGaragem;
	Button btPortao;
	Button btOnChaveGeral;
	Button btOffChaveGeral;
	Button btOnAlarme;
	
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        
        /*
         * Caso o Bluetooth estiver desativado, pede para o usuario ativa-lo
         */
        if (!mBluetoothAdapter.isEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
        }
        /*
         * Iniciando a conex�o Bluetooth SSP
         */
        mBluetoothSPPConnection = new BluetoothSPPConnection(this); 
        
        /*
         * Iniciando o bot�o conectar
         * Registrando no OnClickListener
         */
        Button bt = (Button) findViewById(R.id.connect);
        bt.setText("Conectar");
        bt.setOnClickListener(new OnClickListener() {
			
			public void onClick(View v) {
				/*
				 * Quando n�o estiver conectado, inicie o DeviceListActivity que vai permitir ao usuario
				 * selecionar um dispostivo para conectar.
				 * A atividade vai retornar o bluetoothdevice.
				 * Fun��o membro � chamado
				 */
				if (!connected) {
					Intent serverIntent = new Intent(v.getContext(), DeviceListActivity.class);
					startActivityForResult(serverIntent, REQUEST_CONNECT_DEVICE);
				/*
				 * Quando ligado feche a conex�o bluetooth
				 */
				} else {
					mBluetoothSPPConnection.close();
				}
			}
		});

        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        wl = pm.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK, "My Tag");
        wl.acquire();
        
    }
    
    @Override
	protected void onDestroy() {
		super.onDestroy();
		
		/*
		 * Fechar a conex�o bluetooth
		 */
		mBluetoothSPPConnection.close();
	}

    
    
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

    	switch (requestCode) {
        case REQUEST_CONNECT_DEVICE:
        	if (resultCode == Activity.RESULT_OK) {
            	String address = data.getExtras().getString(DeviceListActivity.EXTRA_DEVICE_ADDRESS);
                BluetoothDevice device = mBluetoothAdapter.getRemoteDevice(address);
                mBluetoothSPPConnection.open(device);                
            }
            break;
        case REQUEST_ENABLE_BT:
        	if (resultCode == Activity.RESULT_OK) {
        	}
        	break;
        }
    }

	public void onAccuracyChanged(Sensor sensor, int accuracy) {

	}

	public void onSensorChanged(SensorEvent event) {

 
	}


	/*
	 * Funcao que e executada durante a conexao
	 */
	public void onConnecting() {
		TextView connectionView = (TextView) findViewById(R.id.connectionInfo);
		connectionView.setText("Conectando...");
	}

	public void onConnected() {

		connected = true;

		TextView connectionView = (TextView) findViewById(R.id.connectionInfo);
		connectionView.setText("Conectado "+mBluetoothSPPConnection.getDeviceName());

		Button bt = (Button) findViewById(R.id.connect);
		bt.setText("Conectado");

		final byte[] command = new byte[1];
		command[0]='K';
		mBluetoothSPPConnection.write(command);
		CarregarMenuPrincipal();				
	}
	public void bluetoothWrite(int bytes, byte[] buffer) {

	}
	
	public void CarregarMenuPrincipal(){
		/*
		 * Carrega o layout main
		 */
		setContentView(R.layout.main);
 
		/*
		 * Seta todos os botoes com as id do layout main
		 */
		
		btCozinha = (Button) findViewById(R.id.btcozinha);
		btSala = (Button) findViewById(R.id.btsala);
		btQuarto = (Button) findViewById(R.id.btquarto);
		btBanheiro = (Button) findViewById(R.id.btbanheiro);
		btGaragem = (Button) findViewById(R.id.btgaragem);
		btCasa = (Button) findViewById(R.id.btcasa);
		
		/*
		 * Este Metodo serve para se cada o botao cozinha se clicado
		 */
		
		btCozinha.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				/*
				 * Carrega o layout cozinha, seta os botoes e o log
				 */
				setContentView(R.layout.cozinha);
				btLuzCozinha = (Button) findViewById(R.id.btLuzCozinha);
				btVoltarMenu = (Button) findViewById(R.id.voltarMenu);
				
				edlog = (EditText) findViewById(R.id.Log);
				edlog.append("\n\n\nLog: \n");	
				/*
				 * Metodo se caso o Botao Luz do layout cozinha for clicado
				 */
				btLuzCozinha.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						/*
						 * Declara um byte, envia o 'C' por bluetooth e mostra mensagem no log
						 */
						final byte[] lc = new byte[1];
						lc[0] = 'C';
						mBluetoothSPPConnection.write(lc);
						edlog.append("\n\n\nLog: Comando Aceito \n");
					}
				});
				/*
				 * Metodo se caso o Botao Voltar ao Menu Principal for clicado
				 */
				btVoltarMenu.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						CarregarMenuPrincipal();				
					}
				});
			}
		});
		/*
		 * Este metodo serve para se cada o botao sala se clicado
		 */
		btSala.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				/*
				 * Carrega o layout sala, seta os botoes e o log
				 */
				setContentView(R.layout.sala);
				btLuzSala = (Button) findViewById(R.id.btLuzSala);
				btVentiladorSala = (Button) findViewById(R.id.btVentiladorSala);
				btVoltarMenu = (Button) findViewById(R.id.voltarMenu);
				edlog = (EditText) findViewById(R.id.Log);
				edlog.append("\n\n\nLog: \n");	
				/*
				 * Metodo se caso o Botao Luz Sala for clicado
				 */
				btLuzSala.setOnClickListener(new View.OnClickListener() {	
					@Override
					public void onClick(View v) {
						/*
						 * Declara um byte, envia o 'S' por bluetooth e mostra mensagem no log
						 */
						final byte[] lc = new byte[1];
						lc[0] = 'S';
						mBluetoothSPPConnection.write(lc);
						edlog.append("\n\n\nLog: Comando Luz Aceito \n");
					}
				});
				/*
				 * Metodo se caso o Botao Ventilador Sala for clicado
				 */
				btVentiladorSala.setOnClickListener(new View.OnClickListener() {	
					@Override
					public void onClick(View v) {
						/*
						 * Declara um byte, envia o 'V' por bluetooth e mostra mensagem no log
						 */
						final byte[] lc = new byte[1];
						lc[0] = 'V';
						mBluetoothSPPConnection.write(lc);
						edlog.append("\n\n\nLog: Comando Ventilador Aceito \n");
					}
				});
				/*
				 * Metodo se caso o Botao Voltar ao Menu Principal for clicado
				 */
				btVoltarMenu.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						CarregarMenuPrincipal();				
					}
				});
			}
	});
		/*
		 * Este metodo serve para se cada o botao quarto se clicado
		 */
		btQuarto.setOnClickListener(new View.OnClickListener() {		
			@Override
			public void onClick(View v) {
				/*
				 * Carrega o layout quarto, seta os botoes e o log
				 */
				setContentView(R.layout.quarto);
				btLuzQuarto = (Button) findViewById(R.id.btLuzQuarto);
				btVoltarMenu = (Button) findViewById(R.id.voltarMenu);
				edlog = (EditText) findViewById(R.id.Log);
				edlog.append("\n\n\nLog: \n");	
				/*
				 * Metodo se caso o Botao Luz Quarto for clicado
				 */
				btLuzQuarto.setOnClickListener(new View.OnClickListener() {					
					@Override
					public void onClick(View v) {
						/*
						 * Declara um byte, envia o 'Q' por bluetooth e mostra mensagem no log
						 */
						final byte[] lc = new byte[1];
						lc[0] = 'Q';
						mBluetoothSPPConnection.write(lc);
						edlog.append("\n\n\nLog: Comando Luz Aceito \n");
					}
				});
				/*
				 * Metodo se caso o Botao Voltar ao Menu Principal for clicado
				 */
				btVoltarMenu.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						CarregarMenuPrincipal();
					}
				});
			}
		});
		/*
		 * Este metodo serve para se cada o botao banheiro se clicado
		 */
		btBanheiro.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				/*
				 * Carrega o layout banheiro, seta os botoes e o log
				 */
				setContentView(R.layout.banheiro);
				btLuzBanheiro = (Button) findViewById(R.id.btLuzBanheiro);
				btVoltarMenu = (Button) findViewById(R.id.voltarMenu);
				edlog = (EditText) findViewById(R.id.Log);
				edlog.append("\n\n\nLog: \n");	
				/*
				 * Metodo se caso o Botao Luz Banheiro for clicado
				 */
				btLuzBanheiro.setOnClickListener(new View.OnClickListener() {					
					@Override
					public void onClick(View v) {
						/*
						 * Declara um byte, envia o 'B' por bluetooth e mostra mensagem no log
						 */
						final byte[] lc = new byte[1];
						lc[0] = 'B';
						mBluetoothSPPConnection.write(lc);
						edlog.append("\n\n\nLog: Comando Luz Aceito \n");
					}
				});
				/*
				 * Metodo se caso o Botao Voltar ao Menu Principal for clicado
				 */
				btVoltarMenu.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						CarregarMenuPrincipal();
					}
				});
				
			}
		});
		/*
		 * Este metodo serve para se cada o botao garagem se clicado
		 */
		btGaragem.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				/*
				 * Carrega o layout garagem, seta os botoes e o log
				 */
				setContentView(R.layout.garagem);
				btLuzGaragem = (Button) findViewById(R.id.btLuzGaragem);
				btPortao = (Button) findViewById(R.id.btPortao);
				btVoltarMenu = (Button) findViewById(R.id.voltarMenu);
				edlog = (EditText) findViewById(R.id.Log);
				edlog.append("\n\n\nLog: \n");	
				/*
				 * Metodo se caso o Botao Luz Garagem for clicado
				 */
				btLuzGaragem.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						/*
						 * Declara um byte, envia o 'G' por bluetooth e mostra mensagem no log
						 */
						final byte[] lc = new byte[1];
						lc[0] = 'G';
						mBluetoothSPPConnection.write(lc);
						edlog.append("\n\n\nLog: Comando Luz Aceito \n");
					}
				});
				/*
				 * Metodo se caso o Botao Portao Garagem for clicado
				 */
				btPortao.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						/*
						 * Declara um byte, envia o 'P' por bluetooth e mostra mensagem no log
						 */
						final byte[] lc = new byte[1];
						lc[0] = 'P';
						mBluetoothSPPConnection.write(lc);
						edlog.append("\n\n\nLog: Comando Portao Aceito \n");
					}
				});
				/*
				 * Metodo se caso o Botao Voltar ao Menu Principal for clicado
				 */
				btVoltarMenu.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						CarregarMenuPrincipal();
					}
				});
			}
		});
		/*
		 * Este metodo serve para se cada o botao casa se clicado
		 */
		btCasa.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				/*
				 * Carrega o layout casa, seta os botoes e o log
				 */
				setContentView(R.layout.casa);
				btOnChaveGeral = (Button) findViewById(R.id.btOnChave);
				btVoltarMenu = (Button) findViewById(R.id.voltarMenu);
				btOnAlarme = (Button) findViewById(R.id.btOnAlarme);
				edlog = (EditText) findViewById(R.id.Log);
				edlog.append("\n\n\nLog: \n");	
				/*
				 * Metodo se caso o Botao Chave Geral for clicado
				 */
				btOnChaveGeral.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						/*
						 * Declara um byte, envia o 'O' por bluetooth e mostra mensagem no log
						 */
						final byte[] lc = new byte[1];
						lc[0] = 'O';
						mBluetoothSPPConnection.write(lc);
						edlog.append("\n\n\nLog: Comando Chave Geral Aceito \n");
						
					}
				});
				/*
				 * Metodo se caso o Botao Alarme for clicado
				 */
				btOnAlarme.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						/*
						 * Declara um byte, envia o 'A' por bluetooth e mostra mensagem no log
						 */
							final byte[] lc = new byte[1];
							lc[0] = 'A';
							mBluetoothSPPConnection.write(lc);
							edlog.append("\n\n\nLog: Comando Alarme Aceito \n");
					}
				});
				/*
				 * Metodo se caso o Botao Voltar ao Menu Principal for clicado
				 */
				btVoltarMenu.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						CarregarMenuPrincipal();
					}
				});
			}
		});

	}


	public void onConnectionFailed() {
		// This function is called when the intended connection could not be realized.
		// The function is executed in the main thread.

		connected = false;
		
		// Change the text in the connectionInfo TextView
		TextView connectionView = (TextView) findViewById(R.id.connectionInfo);
		connectionView.setText("Conex�o falhou!");

		// Change the text in the connect button.
		Button bt = (Button) findViewById(R.id.connect);
		bt.setText("Conectar");
	}

	public void onConnectionLost() {
		/*
		 * Essa funcao e chamada quando o bluetooth de destino para conectar nao pode ser conectado
		 */
		connected = false;
		
		/*
		 * Altera o connectionInfo
		 */
		TextView connectionView = (TextView) findViewById(R.id.connectionInfo);
		connectionView.setText("N�o est� conectado!");

		/*
		 * Altera o botao da conexao
		 */
		Button bt = (Button) findViewById(R.id.connect);
		bt.setText("Conectar");
	}
}