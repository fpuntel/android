/*
 * 						Universidade Federal de Santa Catarina - UFSC
 * 								   	Campus Ararangu�
 * 						LARM - Laborat�rio de  Automa��o e Rob�tica M�vel
 *								 		D�motica
 *
 * Este software est� licenciado sobre Licen�a Apache, Vers�o 2.0 (a "Licen�a")
 * Voc� n�o pode usar esse arquivo exceto em conformidade com a Licen�a.
 * Voc� pode obter uma c�pia da Licen�a em
 * http://www.apache.org/licenses/LICENSE-2.0
 * A menos que exigido por lei aplic�vel ou acordado por escrito de software,
 * Distribu�do sob a Licen�a � distribu�do "COMO EST�",
 * SEM GARANTIAS OU CONDI��ES DE QUALQUER TIPO, expressa ou impl�cita.
 * Consulte a Licen�a para a linguagem espec�fica que regula permiss�es e
 * Os limita��es sob a Licen�a.
 * Peda�os do c�digo baseado no c�digo do site: http://www.karelbruneel.com/blog/
 *  
 * C�digo com a iten��o de controlar os comodos de uma casa, tanto luz, como alarme e port�o
 * C�digo desenvolvido por Fernando Emilio Puntel (fernandopuntel@gmail.com);
 */
package bluetoothSteeringWheel.karelbruneel.com;

public interface BluetoothSPPConnectionListener {
	public void bluetoothWrite(int bytes, byte[] buffer);
	public void onConnecting();
	public void onConnected();
	public void onConnectionFailed();
	public void onConnectionLost();
}
